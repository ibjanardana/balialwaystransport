<section id="about" class="about">
      <div class="container">

        <div class="row">
          <div class="col-lg-6">
            <img src="<?= base_url('') ?>/assets/img/about-us-1.jpeg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <h3>About Us</h3>
            <p>
            BALI ALWAYS TRANSPORT is a family friendly transport and tour service of your best right choice in bali &#128513. Our services is a tour & tourist transportation service in Bali, We consist of professionals who have experience in the field of tourism. Currently we serve various tourist events in Bali such as daily tours, charter tours, private tours, etc. of course with the quality of vehicles that are clean, safe, well-maintained and comfortable.
            </p>
            </div>
          </div>
        </div>

      </div><br>
    </section>